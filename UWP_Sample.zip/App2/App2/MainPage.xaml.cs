﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace App2
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
            Loaded += MainPage_Loaded;
        }

        private void MainPage_Loaded(object sender, RoutedEventArgs e)
        {
            double top = canvas.Height / 2;
            double left = canvas.Width / 2;
            foreach (TextBlock textblock in canvas.Children)
            {
                Canvas.SetLeft(textblock, left - textblock.ActualWidth / 2);
                Canvas.SetTop(textblock, top - textblock.ActualHeight / 2);
            }
        }

        private void Page_ManipulationDelta(object sender, ManipulationDeltaRoutedEventArgs e)
        {
            double top = canvas.Height / 2;
            double left = canvas.Width / 2;
            foreach (TextBlock textblock in canvas.Children)
            {
                textblock.FontSize = ++textblock.FontSize;
                Canvas.SetLeft(textblock, left - textblock.ActualWidth / 2);
                Canvas.SetTop(textblock, top - textblock.ActualHeight / 2);
            }
            
        }

        private void MainPage_OnDoubleTapped(object sender, DoubleTappedRoutedEventArgs e)
        {
            double top = canvas.Height / 2;
            double left = canvas.Width / 2;
            foreach (TextBlock textblock in canvas.Children)
            {
                textblock.FontSize = 15;
                textblock.Measure(new Size(double.PositiveInfinity,Double.PositiveInfinity));
                Canvas.SetLeft(textblock, left - textblock.ActualWidth / 2);
                Canvas.SetTop(textblock, top - textblock.ActualHeight / 2);
            }
        }
    }
}
