﻿using Android.Content;
using Android.Graphics;
using Issue10364;
using Issue10364.Droid;
using Xamarin.Forms;
using Xamarin.Forms.Platform.Android;

[assembly: ExportRenderer(typeof(CustomView), typeof(CustomViewRenderer))]
namespace Issue10364.Droid
{
    public class CustomViewRenderer : ViewRenderer
    {
        public CustomViewRenderer(Context context) : base(context)
        {
            this.SetWillNotDraw(false);
        }

        protected override void OnDraw(Canvas canvas)
        {
            Paint paint = new Paint();
            this.ClipBounds = new Rect(0, 0, Width, Height);
            this.SetBackgroundColor(Android.Graphics.Color.LightGray);
            int[] colors = new int[4] { Android.Graphics.Color.Argb(255, 255, 153, 85), Android.Graphics.Color.Argb(255, 255, 153, 85), Android.Graphics.Color.Argb(255, 255, 153, 85), Android.Graphics.Color.Argb(255,255,153,85) };
            float[] offsets = new float[4] { 0,0.5f,0.5f, 1 };
            LinearGradient gradient = new LinearGradient(0, 0, this.Width, this.Height, colors, offsets, Shader.TileMode.Clamp);
            paint.SetShader(gradient);
            canvas.Save();
            canvas.DrawPaint(paint);
            canvas.Restore();
            base.OnDraw(canvas);
        }
    }
}