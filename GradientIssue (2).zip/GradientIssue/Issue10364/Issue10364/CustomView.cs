﻿using System.ComponentModel;
using Xamarin.Forms;

namespace Issue10364
{
    [DesignTimeVisible(true)]
    public class CustomView : View
    {

    }
}